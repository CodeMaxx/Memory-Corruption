#include<stdio.h>

int main()
{
	char buffer[64];
	gets(buffer);
	return 0;
}
